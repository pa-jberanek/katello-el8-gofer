from __future__ import absolute_import

try:
    import simplejson as json
except ImportError:
    import json


from .builtin import str, basestring
